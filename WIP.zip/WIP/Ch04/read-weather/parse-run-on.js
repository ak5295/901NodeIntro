//Using promisify
const {promisify} = require('util')
const fs = require('fs')
const readFileAsync = promisify(fs.readFile)

readFileAsync(`${__dirname}/run-on.txt`, {encoding: 'utf8'})
  .then(contents => {
      let lengthOfFile=contents.length;
      
     
      for (let i=0; i< lengthOfFile; i=i+80) {
        // console.log(contents.slice(0, 79));
        console.log(contents.slice(i, i+80));
      }
    // const runonArray = String.parse(contents);
    // console.log(runonArray);

    // runonArray.forEach(element => {
    //     console.log(element)
    // });
  })
  .catch(error => {
    console.log(error);
  });