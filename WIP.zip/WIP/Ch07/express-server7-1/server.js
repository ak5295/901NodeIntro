const express = require("express");

const config = require("./config.json");

let app = express();

app.use(require("./routes/index3.js"));

app.listen(config.port, () => {
	console.log(`Listening on http://localhost:${config.port} ...`);
});
