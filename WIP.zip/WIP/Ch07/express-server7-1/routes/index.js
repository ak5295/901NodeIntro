const express = require("express");

let router = express.Router();



router.get("/", (req, res) => {
	res.send("Hello world! From the main page");
});

router.get("/about", (req, res) => {
	res.send("Hello world! From about page");
});

router.get("/class", (req, res) => {
	res.send("Hello world! From class tools page, welcome to the class page");
});

router.get("/weather", (req, res) => {
	let message ="";
	for (var i = 1; i < 8; i++) {
		let randomNumber = Math.floor(Math.random() * 100);
		let temp = randomNumber[i-1];
		if (randomNumber >= temp) {
			message=message+"Hello world! From weather page="+ i;
		}
		else {
			message=message+"weather="+randomNumber;
		}	

	}
	res.send("weather="+message);
// 	const Promise = require("bluebird");
// 	const knex = require("knex");
// 	let db = knex(require("./knexfile"));


// Promise.try(() => {
// 	return db.schema.createTable("weather", (table) => {
// 		table.increments("id").primary();
// 		table.text("temperature");
// 	});
// }).then(() => {
// 	console.log("Created Table!");
// }).then(() => {
// 	return db("weather").insert([{
// 		temperature: "32"
// 	}, {
// 		temperature: "70"
// 	}]);
// }).then(() => {
// 	console.log("Inserted records!");
// }).then(() => {
// 	return db("weather");
// }).then((weather) => {
// 	console.log("All the people:", weather);
// }).finally(() => {
// 	db.destroy();
// });
// res.send("weather="+message);
});

module.exports = router;

