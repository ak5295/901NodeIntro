

const express = require("express");
const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));
// const knex = require("knex");

// let db = knex(require("../knexfile"));

let router = express.Router();



router.get("/", (req, res) => {
	res.send("Hello world! From the main page");
});

router.get("/about", (req, res) => {
	res.send("Hello world! From about page");
});

router.get("/class", (req, res) => {
	res.send("Hello world! From class tools page, welcome to the class page");
});

router.get("/weather", (req, res) => {
	

	Promise.try(() => {
		return fs.readFileAsync("./input.txt");
		
	}).then((fileContents) => {
		console.log(fileContents.toString());
		res.send("weather="+fileContents.toString());
	}).catch((err) => {
		console.error("An error occurred", err);
	});


console.log('End of program file');
});
module.exports=router;
	// for (var i = 1; i < 8; i++) {
	// 	let randomNumber = Math.floor(Math.random() * 100);
	// 	let temp = randomNumber[i-1];
	// 	if (randomNumber >= temp) {
	// 		message=message+"Hello world! From weather page="+ i;
	// 	}
	// 	else {
	// 		message=message+"weather="+randomNumber;
	// 	}	

	// }
	// res.send("weather="+message);


// Promise.try(() => {
// 	return db.schema.createTable("weather", (table) => {
// 		table.increments("id").primary();
// 		table.text("temperature");
// 	});
// }).then(() => {
// 	console.log("Created Table!");
// }).then(() => {
// 	return db("weather").insert([{
// 		temperature: "32"
// 	}, {
// 		temperature: "70"
// 	}]);
// }).then(() => {
// 	console.log("Inserted records!");
// }).then(() => {
// 	return db("weather");
// }).then((weather) => {
// 	console.log("All the people:", weather.temperature);
// 	let weatherOutput = "";
// 	weather.forEach(element => {
// 		weatherOutput = weatherOutput+", "+element.temperature;
		
// 	});
// 	res.send("weather="+weatherOutput);
// }).finally(() => {
// 	db.destroy();
// });

// });



