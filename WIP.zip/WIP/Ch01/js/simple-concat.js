let firstName = 'Lillian';
let lastName = 'Lee';

console.log(
`Hello 
${firstName} ${lastName}`);
