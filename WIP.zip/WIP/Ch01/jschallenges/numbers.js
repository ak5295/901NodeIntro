let number = 123456789;
console.log(number);