// var example = {
//     pizza: 'yummy'
//   };

//   console.log(example['pizza']);

  var food = {
    types: 'only pizza'
  };

  console.log(food['types']);