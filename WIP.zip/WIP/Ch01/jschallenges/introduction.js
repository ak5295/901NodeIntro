// console.log('hello');
// console.log('this is a string');
// console.log('pizza is wonderful');
// numbers
// console.log(123456789);
// number
// console.log(2);
// console.log(128);

//you can do this!
//Look at demos for examples
//MDN is a good resource
//W3schools is .. ok too!
//if you feel at all lost ask instructor

// console.log('Array.map()');
const mapValues = [1,2,3,4,5];
var index=1;

// var key = Object.keys(mapValues)[index];
// value = mapValues[key];
// console.log(key,value);
let numOfItems = -2;
let inArray=[7, 9, 0];
function first(inArray, numOfItems)
{
    if (!inArray)
        return [];

    if (!numOfItems)
    {
        return inArray[0];
    }

    if (numOfItems < 0)
        return [];
    return inArray.slice(0,numOfItems);
}
console.log(first([7, 9, 0, -2])); 
console.log(first([],3));
console.log(first([7, 9, 0, -2],3));
console.log(first([7, 9, 0, -2],6));
console.log(first([7, 9, 0, -2],-3));

