var fruit=`orange`;
var n = fruit.length;
if (n >= 5){
    console.log(`The fruit name has more than five characters.`);
}    
else {
        console.log('the variable n is less than or equal to 1.');
      }