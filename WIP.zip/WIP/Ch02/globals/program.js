const s=process.argv[2];
console.log(s);

// var r=reverseString(s);
// console.log('reversed='+r);

console.log(s.split("").reverse().join(""));

