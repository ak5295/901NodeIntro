console.log(`current running file: ${__filename}`);
console.log(`current directory: ${__dirname}`);
console.log(`process.argv[0]=`+process.argv[0]);
console.log(`process.argv[1]=`+process.argv[1]);