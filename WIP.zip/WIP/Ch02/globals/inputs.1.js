console.log(process.argv[0]);
console.log(process.argv[1]);


