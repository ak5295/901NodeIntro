module.exports = class Circle {
    constructor(radius) {
      this.radius = radius;
    }
  
    area() {
      return 3.14159 * this.radius ** 2;
    }
  };
