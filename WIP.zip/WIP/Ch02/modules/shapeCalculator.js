const Triangle = require('./triangle.js');
const myTriangle = new Triangle(3, 2);
console.log(`The area of myTriangle is
             ${myTriangle.area()}`);

const Circle = require('./circle.js');
const myCircle = new Circle(3);
console.log(`The area of myCircle is
             ${myCircle.area()}`);

const Square = require('./square.js');
const mySquare = new Square(3);
console.log(`The area of mySquare is
             ${mySquare.area()}`);

