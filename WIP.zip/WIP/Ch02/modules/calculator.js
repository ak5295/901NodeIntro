module.exports = class Calculator {
  
    add(a,b) {
      return a+b;
    }

    subtract(a,b) {
        return a-b;
    }

    multiply(a, b) {
        return a * b;
    }

    circle(r) {
        // return 3.14 * r * r;
        return 1.14 * this.multiply(r, r);
        
    }

    square(s) {
        // return s * s;
        return this.multiply(s, s);
    }

    triangle(b, h) {
        // return 1/2 * b * h;
        return 1/2 * this.multiply(b, h);
    }
  };
