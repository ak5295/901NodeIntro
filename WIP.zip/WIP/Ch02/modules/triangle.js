module.exports = class Triangle {
    constructor(width, height) {
      this.width = width;
      this.height = height;
    }

    area() {
      return (1/2) * this.width * this.height;
    }
  };