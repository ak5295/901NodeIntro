Your WIP directory is where you will do your work.

Do the appropriate steps when instructed in your labs.

